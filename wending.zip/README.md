# 课工厂文鼎官网
    > 首页制作
    > webpack+sass
# 💪🏻 start
1. npm i    

2. npm run serve    

  > 启动webpack-dev-serve  

3. 入口文件为src/js/index.js,css等可以从这里import进来，具体配置看webpack.config.js  
# auth
### 🙀 webliqianmin
### 😇 chanbaihai
